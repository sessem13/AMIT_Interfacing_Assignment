/*
* TWI.c
*
* Created: 2/20/2021 8:57:13 PM
*  Author: karim
*/

#include "TWI.h"

void TWI_MASTER_Init(void)
{
	TWBR = 0x0C;				/*Prescaler of the clock*/
	//Set the TWEN bit in the TWCR register to ensure I2C is enabled.
	SET_BIT(TWCR, TWEN);		/*Enable Two wire Interface*/
}
void TWI_SLAVE_Init(void)
{
	/*Set address for slave*/
	TWAR = (0x01 << 1); /*Disable general call*/
	SET_BIT(TWCR, TWEA);/*Slave enable acknowledgment*/
	SET_BIT(TWCR, TWEN);/*Enable Two wire Interface*/
}
void TWI_START_Condition(void)
{
	//Write 1 to the TWSTA bit in the TWCR register.
	//Setting this bit makes the MCU send a start signal on the bus when it is free, to declare that MCU is currently controlling the bus and will start transmitting data.
	SET_BIT(TWCR, TWSTA);		/*Start condition*/
	//Write 1 to the TWINT bit in the TWCR register to clear the interrupt flag.
	//This bit is set to 1 by the hardware when the I2C module finishes its current job and is ready to get more commands from the SW.
	//Also clearing this bit starts the I2C module immediately. 
	//So every time we want to start the I2C module, we must ensure clearing this bit first and we shall poll till it becomes 1 again because this indicates the I2C has successfully executed the task.
	//Note: that this bit is never cleared by the MCU Hardware, you must clear it by Software.
	SET_BIT(TWCR, TWINT);		/*Hard set for flag waiting for dominant bit (0)*/
	while(GET_BIT(TWCR, TWINT) != 0);		/*When start condition finished*/ //<<<<POLLING>>>>
	while((TWSR & 0xF8) != START_ACK);		/*Waiting for master send start condition*/ //<<<<POLLING>>>>
}
void TWI_REPEATED_Condition(void)
{
	TWCR = (1 << 7) | (1 << 5) | (1 << 2);
	SET_BIT(TWCR, TWINT);/*Hard set for flag waiting for dominant bit (0)*/
	while(GET_BIT(TWCR, TWINT) != 0);/*When start condition finished*/
	while((TWSR & 0xF8) != REP_START_ACK);/*Waiting for master send start condition*/
}
void TWI_SLAVE_WRITE_Data(uint8_t address)
{
	TWDR = (address << 1) | (0x00);/*Send address of chosen slave, Write*/
	TWCR = (1 << 7) | (1 << 2);
	while(GET_BIT(TWCR, TWINT) != 0);/*When start condition finished*/
	while((TWSR & 0xF8) != SLAVE_ADD_AND_WR_ACK);/*Waiting for slave send start ACK*/
}
void TWI_SLAVE_READ_Data(uint8_t address)
{
	TWDR = (address << 1) | (0x01);/*Send address of chosen slave, Read*/
	TWCR = (1 << 7) | (1 << 2);
	while(GET_BIT(TWCR, TWINT) != 0);/*When start condition finished*/
	while((TWSR & 0xF8) != SLAVE_ADD_AND_RD_ACK);/*Waiting for slave send start ACK*/
}
void TWI_TRANSMIT_Data(uint8_t data)
{
	//Start TWI Data Transmission:
	//After taking control of the bus, the MCU can send information to it. This is achieved through the steps below:
	//1- Put the data you need to send in the TWI Data Register.	
	//2- Write 1 to the TWEN bit in the TWCR register to ensure I2C is enabled.
	//3- Write 1 to the TWINT bit in the TWCR register to ensure it is cleared.
	//4- Poll the TWINT bit (previously cleared) until it becomes 1. Once this bit is set, it means that the transmission is complete.
	TWDR = data;
	TWCR = (1 << 7) | (1 << 2);
	while(GET_BIT(TWCR, TWINT) != 0);/*When start condition finished*/ //<<<<POLLING>>>>
	while((TWSR & 0xF8) != WR_BYTE_ACK);/*Waiting for slave send start ACK*/ //<<<<POLLING>>>>
}
uint8_t TWI_RECEIVE_Data(void)
{
	//Receiving TWI data is even easier than transmitting. You need to follow these steps:
	//1- Write 1 to the TWEN bit in the TWCR register to ensure I2C is enabled.
	//2- Write 1 to the TWINT bit in the TWCR register to ensure it is cleared.
	//3- Poll the TWINT bit until it becomes 1.
	//4- Read data from the TWDR register.
	TWCR = (1 << 7) | (1 << 2);
	while(GET_BIT(TWCR, TWINT) != 0);/*When start condition finished*/ //<<<<POLLING>>>>
	while((TWSR & 0xF8) != RD_BYTE_WITH_ACK);/*Waiting for slave send start ACK*/ //<<<<POLLING>>>>
	return TWDR;
}
void TWI_STOP_Condition(void)
{
	//Stop transmission and Release the TWI bus:
	//Once you finish data transmission, you should release the bus so that other devices can use it. This is achieved through the following steps:
	//1- Write 1 to the TWEN bit in the TWCR register to ensure I2C is enabled.
	//2- Write 1 to the TWINT bit in the TWCR register to ensure it is cleared.
	//3- Write 1 to the TWSTO bit in the TWCR register to send a stop signal and release the bus.
	SET_BIT(TWCR, TWSTO);/*Send stop condition*/
}