/*
 * S7SEG.c
 *
 * Created: 8/13/2021 8:40:20 PM
 *  Author: 20100
 */ 

#include "Seven_Segment.h"

void Seven_Seg_Initialization(void)
{
	//Define direction for pins:
	DIO_SetPin_Direction(S7SEG_CNTRL_PORT, S7SEG_EN1, S7SEG_OUTPUT);
	DIO_SetPin_Direction(S7SEG_CNTRL_PORT, S7SEG_EN2, S7SEG_OUTPUT);
	//DIO_SetPin_Direction(S7SEG_CNTRL_PORT, S7SEG_DIP, S7SEG_OUTPUT);
	//---------------------------------------------------------------
	DIO_SetPin_Direction(S7SEG_DATA_PORT, S7SEG_DTA_A, S7SEG_OUTPUT);
	DIO_SetPin_Direction(S7SEG_DATA_PORT, S7SEG_DTA_B, S7SEG_OUTPUT);
	DIO_SetPin_Direction(S7SEG_DATA_PORT, S7SEG_DTA_C, S7SEG_OUTPUT);
	DIO_SetPin_Direction(S7SEG_DATA_PORT, S7SEG_DTA_D, S7SEG_OUTPUT);
	//================================================================
	//initialize all pins for module:
	DIO_SetPin_State(S7SEG_CNTRL_PORT, S7SEG_EN1, S7SEG_LOW);
	DIO_SetPin_State(S7SEG_CNTRL_PORT, S7SEG_EN2, S7SEG_LOW);
	//DIO_SetPin_State(S7SEG_CNTRL_PORT, S7SEG_DIP, S7SEG_LOW);
	//--------------------------------------------------------
	DIO_SetPin_State(S7SEG_DATA_PORT, S7SEG_DTA_A, S7SEG_LOW);
	DIO_SetPin_State(S7SEG_DATA_PORT, S7SEG_DTA_B, S7SEG_LOW);
	DIO_SetPin_State(S7SEG_DATA_PORT, S7SEG_DTA_C, S7SEG_LOW);
	DIO_SetPin_State(S7SEG_DATA_PORT, S7SEG_DTA_D, S7SEG_LOW);
	//================================================================
}


void S7SEG_Enable1(void)
{
	DIO_SetPin_State(S7SEG_CNTRL_PORT, S7SEG_EN1, S7SEG_HIGH);
}

void S7SEG_Disable1(void)
{
	DIO_SetPin_State(S7SEG_CNTRL_PORT, S7SEG_EN1, S7SEG_LOW);
}


void S7SEG_Enable2(void)
{
	DIO_SetPin_State(S7SEG_CNTRL_PORT, S7SEG_EN2, S7SEG_HIGH);
}

void S7SEG_Disable2(void)
{
	DIO_SetPin_State(S7SEG_CNTRL_PORT, S7SEG_EN2, S7SEG_LOW);
}

/*
void S7SEG_DIP_Enable(void)
{
	DIO_SetPin_State(S7SEG_CNTRL_PORT, S7SEG_DIP, S7SEG_HIGH);
}

void S7SEG_DIP_Disable(void)
{
	DIO_SetPin_State(S7SEG_CNTRL_PORT, S7SEG_DIP, S7SEG_LOW);
}
*/

void Seven_Segment_Write_Number(uint8_t number)
{
	uint8_t data0 = number % 10;//Get number in units
	uint8_t data1 = number / 10;//Get number in tens
	//PORTD = number;
	S7SEG_Enable1();
	S7SEG_Disable2();
	PORTD = (data1<<4) | (PORTD & 0x0F);//0b00001111
	_delay_us(200);
	S7SEG_Enable2();
	S7SEG_Disable1();
	PORTD = (data0<<4) | (PORTD & 0x0F);//0b00001111
	_delay_us(200);
}