/*
 * Timer0_Config.h
 *
 * Created: 8/27/2021 9:21:13 PM
 *  Author: Osama
 check these links:
 https://exploreembedded.com/wiki/AVR_Timer_programming
 https://www.electronicwings.com/avr-atmega/atmega1632-timer
 */ 

#ifndef TIMER0_CONFIG_H_
#define TIMER0_CONFIG_H_

#include "CPU_Configuration.h"
#include "Timer0_Address.h"
//Timer0 registers:

/*----------------------------------------------------------------------------------------------------------*/
#define F_OSC                  16		//just a name for the oscillator number to use in calculation *10^6
#define PRESCALER              1024		//Prescaler here is 1024 but it can be selected when configuring the TCCR0 register pins CS02,CS01,CS00
/*
TCCR0 or Timer/Counter Control Register:
| Bit7 | Bit6 | Bit5 | Bit4 | Bit3 | Bit2 | Bit1 | Bit0 |
| FOC0 |WGM00 |COM01 |COM00 |WGM01 | CS02 | CS01 | CS00 |
*/
#define MicroSecond            1000    //value needed to work with?
#define Number_Bits            256		// name for the maximum value that register TCNT0 can hold then it will overflow and make the TOV0 flag 1

/* 
Defining Modes of operation of Timer0:
| Bit6 | Bit3 |
|WGM00 |WGM01 | Mode
|  0   |  0   | Normal Mode									  | --> 0
|  0   |  1   | CTC Mode or Clear Timer on compare match mode | --> 1
|  1   |  0   | PWM phase correct mode						  | --> 2
|  1   |  1   | Fast PWM Mode								  | --> 3
*/
#define Normal_Mode            0
#define CTC_Mode               1
#define PhaseCorrect_PWM_Mode  2
#define Fast_PWM_Mode          3

// I don't know what is the OC0 and what does it do
//PWM output will be generated on the corresponding Timer�s output compare pin (OCx). OC0 for timer0, OC1 for timer1, and OC2 for timer2
//It's related to PWM mode of operation
#define OC0_Disconnected       0
#define OC0_Toggle_Pin         1
#define OC0_Set_Pin            2
#define OC0_Clear_Pin          3
/*
Prescaler Table from the data sheet: "Register TCCR0"
| Bit2 | Bit1 | Bit0 |
| CS02 | CS01 | CS00 | Description
|  0   |  0   |  0   | Disconnect CLK Timer0 OFF
|  0   |  0   |  1   | Just the CLK, No prescaling
|  0   |  1   |  0   | CLK/8
|  0   |  1   |  1   | CLK/64
|  1   |  0   |  0   | CLK/256
|  1   |  0   |  1   | CLK/1024
|  1   |  1   |  0   | External CLK on T0 pin working of falling edge
|  1   |  1   |  1   | External CLK on T0 pin working on rising edge
*/
#define PRE_0                  0  // NO CLK
#define PRE_1                  1  // No Prescaling
#define PRE_8                  2  // CLK/8
#define PRE_64                 3  // CLK/64
#define PRE_256                4  // CLK/256
#define PRE_1024               5  // CLK/1024

#define Timer0_Mode            Normal_Mode
#define Timer0_Prescaler       PRE_1024

#endif /* TIMER0_CONFIG_H_ */