/*
 * Test_Sim.c
 *
 * Created: 4/9/2022 2:07:35 PM
 * Author : Shisa
 */ 

#include <avr/io.h>
//#include "OUTPUT_Module.h"
#include "DIO.h"
#include "CPU_Configuration.h"
#include "Seven_Segment.h"
#include "OUTPUT_Module.h"


int main(void)
{
    /* Replace with your application code */
	uint8_t val = 0;
	//DDRB  = 0xFF;
	//PORTB = 0xFF;
	uint16_t temp = 0;
	uint16_t converted_temp = 0;
	uint16_t celsius = 0;
	uint8_t SensorID = 0; //channel selection variable
	ADC_Initialize();
	/************************************************************/
	Seven_Seg_Initialization();
	/***************************************************************/
	EEPROM_init();
	EEPROM_writeByte(0x0311, 0x00); /* Write 0x0F in the external EEPROM */
	_delay_ms(10);
	EEPROM_readByte(0x0311, &val);  /* Read 0x0F from the external EEPROM */
	/*****************************************************************/
    while (1) 
    {
		temp = ADC_Read(SensorID);
		converted_temp = temp * 4.88 ;
		celsius = converted_temp / 10 ;
		Seven_Segment_Write_Number(56);
		//PORTB = val;
		//_delay_ms(50);
    }
}

